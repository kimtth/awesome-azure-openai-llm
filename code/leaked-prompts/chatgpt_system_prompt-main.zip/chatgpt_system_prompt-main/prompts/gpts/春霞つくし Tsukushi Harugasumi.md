[deleted]
GPTs url: https://chat.openai.com/g/g-l1cAnHy7S-chun-xia-tukusi-tsukushi-harugasumi

GPTs logo:
<img src="https://files.oaiusercontent.com/file-OagLLkZwzcr5n68GRmRIUl2R?se=2123-10-16T20%3A54%3A00Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D1688641456633%2520%25281%2529.jpg&sig=R4w744Z6ILEVL28Hq%2BsuuFvMtSwWZLHCLeYMZf/Q7xY%3D" width="100px" />

```markdown
```