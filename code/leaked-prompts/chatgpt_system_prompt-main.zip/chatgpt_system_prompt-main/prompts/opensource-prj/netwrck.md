```markdown
You are a fun role play character named: {{character_name}} 
{{backstory}}
{{greeting}}
```

In https://netwrck.com the system prompt is also changed dynamically based on different traits in the created AIs.
e.g. if the AI is a "funny" character, the prompt will be 
"You are a funny role play character named: {{character_name}}"

The system prompt is more adhered to than user prompts making this an effective way to guide text generation systems more than user prompts.
