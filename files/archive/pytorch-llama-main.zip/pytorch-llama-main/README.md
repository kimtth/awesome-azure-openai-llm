# pytorch-llama
LLaMA 2 implemented from scratch in PyTorch
